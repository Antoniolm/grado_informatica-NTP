/**
  * Created by LENOVO on 04/04/2017.
  */
object Ejercicio2 extends App{

  def fibonacci(n:Int): Int ={
    if(n==0 || n==1) n
    else fibonacci(n-1)+fibonacci(n-2)
  }
  val result=fibonacci(9)
  println(result)

  def fibonacciTailRec(n:Int): Int ={
    @annotation.tailrec
    def iterar(n:Int,act:Int,sig:Int):Int ={
      if(n==0) act
      else iterar(n-1,sig,act+sig)
    }
    iterar(n,0,1)
  }

  val result1=fibonacciTailRec(9)
  println("Prueba ->"+result1)
}
